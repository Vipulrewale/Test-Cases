package Test;

import java.io.File;
import java.util.logging.FileHandler;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.beust.jcommander.Parameter;

import io.github.bonigarcia.wdm.WebDriverManager;
import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;

public class Login {

	WebDriver driver;

	@Test(priority = 1)
	public void launchBrowser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://testffc.nimapinfotech.com/customers");
	}
	
	@Parameters({"EmailID", "Password"})
	@Test(priority = 2)
	public void login(String EmailID, String Password) throws Exception {
		driver.findElement(By.xpath("//input[@ng-reflect-placeholder=\"Email Id / Mobile No\"]")).sendKeys(EmailID);
		driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys(Password);

		try {
			WebElement captcha = driver.findElement(By.xpath("//canvas[@id=\"captcahCanvas\"]"));
			File src = captcha.getScreenshotAs(OutputType.FILE);
			String path = "C:\\Users\\vipul\\eclipse-workspace\\NImap\\Captcha Images\\captcha.png";
			org.openqa.selenium.io.FileHandler.copy(src, new File(path));
			Thread.sleep(2000);
			ITesseract image = new Tesseract();
			String str = image.doOCR(new File(path));
			System.out.println("Image oCR done");
			System.out.println(str);
			
			driver.findElement(By.xpath("//input[@ng-reflect-name=\"captchaValue\"]"));
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("No exception found" + e.getMessage());
		}
		driver.findElement(By.id("kt_login_signin_submit")).click();
	}

	@Test(priority = 3)
	public void validate() {
		String expectedOutput = "Test Field Force";
		String actualOutput = driver.getTitle();
		Assert.assertEquals(expectedOutput, actualOutput);
	}

	@Test(priority = 4)
	public void addCustomer() {
		driver.findElement(By.xpath("//button[@mattooltip=\"Create new customer\"]")).click();
		driver.findElement(By.xpath("//input[@ng-reflect-name=\"LeadName\"]")).sendKeys("Tommy");
		driver.findElement(By.xpath("//input[@ng-reflect-name=\"PersonName\"]")).sendKeys("Harry");
		driver.findElement(By.xpath("//input[@id=\"mat-input-49\"]")).sendKeys("9945782250");
		driver.findElement(By.xpath("//input[@ng-reflect-name=\"Email\"]")).sendKeys("trycatchvipul@gmail.com");
		driver.findElement(By.id("id=\"mat-input-52\"")).sendKeys("Manager");
		driver.findElement(By.xpath("//button[@ng-reflect-message=\"Save changes\"]")).click();
	}
}
